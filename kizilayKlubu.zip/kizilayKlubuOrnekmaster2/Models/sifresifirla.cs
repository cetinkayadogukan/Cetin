using System.ComponentModel.DataAnnotations;

public class SifreSifirla
{


    [Required(ErrorMessage ="Şifre Tekrarı Boş Bırakılamaz")]
    public string Email { get; set; }

    
    [Required(ErrorMessage ="Şifre Tekrarı Boş Bırakılamaz")]
    public string Token { get; set; }


     [Display(Name ="Şifre")]
     [DataType(DataType.Password)]
     [Required(ErrorMessage ="Şifre Boş Bırakılamaz")]
    public string Sifre { get; set; }


    [Compare("Sifre")]
    [Display(Name="Şifre Tekrarı")]
    [DataType(DataType.Password)]
    [Required(ErrorMessage ="Şifre Tekrarı Boş Bırakılamaz")]
    public string SifreTekrari { get; set; }
    
}